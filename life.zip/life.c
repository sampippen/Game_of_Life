//
// Created by Sam Pippen on 9/11/2020.
//

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "life.h"

//copy character for character without strcpy
void copyGrid(char** grid1, char** grid2, int numStrings){
    for(int i = 0; i < numStrings; i++){
        strcpy(grid1[i], grid2[i]);
    }
}

int checkVert(char* grid[], int rowIdx, int colIdx, int rows){
    int neighbors = 0;

    if(rowIdx != 0){                                //check upper cell for neighbor
        if(grid[rowIdx - 1][colIdx] == '1') {
            neighbors++;
        }
    }

    if(rowIdx != (rows - 1)){                       //check lower cell for neighbor
        if(grid[rowIdx + 1][colIdx] == '1') {
            neighbors++;
        }
    }
    return neighbors;
}

int checkHoriz(char* grid[], int rowIdx, int colIdx, int cols){
    int neighbors = 0;

    if(colIdx != 0){                                //check upper cell for neighbor
        if(grid[rowIdx][colIdx - 1] == '1') {
            neighbors++;
        }
    }

    if(colIdx != cols){                       //check lower cell for neighbor
        if(grid[rowIdx][colIdx + 1] == '1') {
            neighbors++;
        }
    }
    return neighbors;
}

int checkDiag(char* grid[], int rowIdx, int colIdx, int rows, int cols){
    int neighbors = 0;

    if((rowIdx == 0) && (colIdx == 0)){                     //check neighbors for top left element
        if(grid[rowIdx + 1][colIdx + 1] == '1'){
            neighbors++;
        }
    }else if((rowIdx == 0) && (colIdx == (cols - 1))){            //check neighbors for top right element
        if(grid[rowIdx + 1][colIdx - 1] == '1'){
            neighbors++;
        }
    }else if((rowIdx == (rows - 1) && (colIdx == 0))){            //check neighbors for bottom left element
        if(grid[rowIdx - 1][colIdx + 1] == '1'){
            neighbors++;
        }
    }else if((rowIdx == (rows - 1)) && (colIdx == (cols - 1))){         //check neighbors for bottom right element
        if(grid[rowIdx - 1][colIdx - 1] == '1'){
            neighbors++;
        }
    }else if(rowIdx == 0){                                  //check neighbors for non-corner top row elements
        if(grid[rowIdx + 1][colIdx + 1] == '1'){
            neighbors++;
        }
        if(grid[rowIdx + 1][colIdx - 1] == '1'){
            neighbors++;
        }
    }else if(rowIdx == (rows - 1)){                               //check neighbors for non-corner bottom row elements
        if(grid[rowIdx - 1][colIdx + 1] == '1'){
            neighbors++;
        }
        if(grid[rowIdx - 1][colIdx - 1] == '1'){
            neighbors++;
        }
    }else if(colIdx == 0){                                  //check neighbors for non-corner left column elements
        if(grid[rowIdx - 1][colIdx + 1] == '1'){
            neighbors++;
        }
        if(grid[rowIdx + 1][colIdx + 1] == '1'){
            neighbors++;
        }
    }else if(colIdx == (cols - 1)){                               //check neighbors for non-corner right column elements
        if(grid[rowIdx - 1][colIdx - 1] == '1'){
            neighbors++;
        }
        if(grid[rowIdx + 1][colIdx - 1] == '1'){
            neighbors++;
        }
    }else{                                                  //check neighbors for any element not touching sides of grid
        if(grid[rowIdx - 1][colIdx - 1] == '1'){
            neighbors++;
        }
        if(grid[rowIdx - 1][colIdx + 1] == '1'){
            neighbors++;
        }
        if(grid[rowIdx + 1][colIdx - 1] == '1'){
            neighbors++;
        }
        if(grid[rowIdx + 1][colIdx + 1] == '1'){
            neighbors++;
        }
    }
    return neighbors;
}

int checkNeighbors(char* grid[], int rowIdx, int colIdx, int rows, int cols){
    int vertNeighbors  = checkVert(grid, rowIdx, colIdx, rows);
    int horizNeighbors = checkHoriz(grid, rowIdx, colIdx, cols);
    int diagNeighbors  = checkDiag(grid, rowIdx, colIdx, rows, cols);
    return vertNeighbors + horizNeighbors + diagNeighbors;
}

void populateWorld(char fname[], char *grid[], int *numRows, int *numCols){
    FILE *fileNamePtr;
    int numRetGetC;
    int numRetGetS;

    //open file
    fileNamePtr = fopen(fname, "r");
    if(fileNamePtr == NULL){
        printf("Error\n");
        return;
    }

    numRetGetC = fgetc(fileNamePtr);
    *numCols = 0;

    //count number of column in opened text file
    do{
        (*numCols)++;
        numRetGetC = fgetc(fileNamePtr);
    }
    while(numRetGetC != '\n');

    char tempString[(*numCols) + 1];

    fseek(fileNamePtr, 0L, SEEK_SET);

    //count number of rows in opened text file
    *numRows = 0;
    while(fgets(tempString, 80, fileNamePtr) != NULL){
        if(tempString[0] != '\n'){
            (*numRows)++;
        }
    }

    fseek(fileNamePtr, 0L, SEEK_SET);

    //malloc space for grid, then store into text file rows into grid
    for(int i = 0; i < *numRows; i++){
        grid[i] = (char*)malloc(((*numCols) + 2) * sizeof(char));
        fgets(grid[i], 80, fileNamePtr);
    }

    fclose(fileNamePtr);
}

void showWorld(char *grid[], int numRows, int numCols){
    for(int i = 0; i < numRows; i++){
        for(int j = 0; j < numCols; j++){
            if(grid[i][j] == '0'){
                printf("%c", '.');
            }else{
                printf("%c", '*');
            }
        }
        printf("\n");
    }
}

void iterateGeneration(char *grid[], int numRows, int numCols){
    int numNeighbors;
    char *newWorld[numRows];

    //allocate enough memory for an array that will carry new info for world array
    for(int i = 0; i < numRows; i++){
        newWorld[i] = (char*)malloc((numCols + 2) * sizeof(char));
    }

    //copies grid to newWorld
    copyGrid(newWorld, grid, numRows);

    numNeighbors = 0;
    for(int i = 0; i < numRows; i++){
        for(int j = 0; j < numCols; j++){
            numNeighbors = checkNeighbors(grid, i, j, numRows, numCols);
            if((grid[i][j] == '0') && (numNeighbors == 3)){
                newWorld[i][j] = '1';                         //newWorld is new
            }else if(grid[i][j] == '1'){
                if((numNeighbors == 0) || (numNeighbors == 1) || (numNeighbors >= 4)){
                    newWorld[i][j] = '0';                     //newWorld is new
                }
            }
        }
    }

    copyGrid(grid, newWorld, numRows);

    for(int i = 0; i < numRows; i++){
        free(newWorld[i]);
    }
}
