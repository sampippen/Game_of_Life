// life.h
// -- EE 312 Project 2

/* Student information for project:
 *
 * Replace <NAME> with your name.
 *
 * On my honor, Sam Pippen, this programming project is my own work
 * and I have not provided this code to any other student.
 *
 * Name: Sam Pippen
 * email address: samfpippen@utexas.edu
 * UTEID: sfp428
 * Section 5 digit ID: 16020
 *
 *///
// Created by priebe on 9/5/2018.
//

#ifndef LIFE_H
#define LIFE_H

//copies text file info into world grid
void populateWorld(char fname[], char *grid[], int *numRows, int *numCols);

//displays world grid info where 0 = "." and 1 = "*"
void showWorld(char *grid[], int numRows, int numCols);

//checks each cell for neighbors and determines life or death of each cell then makes life/death changes on world grid
void iterateGeneration(char *grid[], int numRows, int numCols);

//copies info of one grid into the other
void copyGrid(char** grid1, char** grid2, int numStrings);

//checks for neighbors given a particular cell index
int checkNeighbors(char* grid[], int rowIdx, int colIdx, int rows, int cols);

//checks for neighbors above and below cell depending on cell location in grid
int checkVert(char* grid[], int rowIdx, int colIdx, int rows);

//checks for neighbors to the left and right for each cell
int checkHoriz(char* grid[], int rowIdx, int colIdx, int cols);

//checks diagonally for neighbors for a given cell
int checkDiag(char* grid[], int rowIdx, int colIdx, int rows, int cols);

#endif